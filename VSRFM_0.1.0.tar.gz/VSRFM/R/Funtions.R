library('randomForest')

# This function compute VSRFM score for not splice variants in a dataframe with VSRFM constituent scores:
# 1) gnomAD_AF
# 2) CADD_PHRED
# 3) Condel
# 4) DANN_score
# 5) MetaLR_score
# 6) MetaSVM_score
# 7) REVEL_score
# 8) phastCons100way_vertebrate
# 9) phastCons20way_mammalian
# 10) phyloP100way_vertebrate
# 11) phyloP20way_mammalian


VSRFM <- function(data){
  table <- data
  prediction <- predict(model.rf, table)
  return(prediction)
}

# This function compute VSRFMs score for splice variants in a dataframe with VSRFM constituent scores:
# 1) gnomAD_AF
# 2) CADD_PHRED
# 3) Condel
# 4) DANN_score
# 5) MetaLR_score
# 6) MetaSVM_score
# 7) REVEL_score
# 8) phastCons100way_vertebrate
# 9) phastCons20way_mammalian
# 10) phyloP100way_vertebrate
# 11) phyloP20way_mammalian
# 12) ada_score
# 13) rf_score


VSRFMs <- function(data){
  table <- data
  prediction <- predict(model.rf.splicing, table)
  return(prediction)
}

